#include "native/ffi/mlx_bridge.cpp"
#include <cassert>
int main() { assert(mlxl3_array_async_eval(nullptr) == -1); }
