#include <metal_stdlib>
using namespace metal;
kernel void mlxl3_rs_moe_routed_reduce_v1(device const half* rotated [[buffer(0)]], device const half* scales [[buffer(1)]], device const uint* selected [[buffer(2)]], device const half* scores [[buffer(3)]], device half* output [[buffer(4)]], uint3 thread_position_in_grid [[thread_position_in_grid]]) {

            uint index = thread_position_in_grid.x;
            uint row = index / 2048u;
            uint column = index % 2048u;
            half total = half(0);
            for (uint slot = 0u; slot < 8u; ++slot) {
                uint route = row * 8u + slot;
                uint expert = selected[route];
                if (expert >= 256u) {
                    output[index] = half(as_type<float>(0x7fc00000u));
                    return;
                }
                half scaled = half(float(rotated[route * 2048u + column])
                    * float(scales[expert * 2048u + column]));
                half weighted = half(float(scaled) * float(scores[route]));
                half partial = weighted + half(0);
                total = partial + total;
            }
            output[index] = total;
        
}
